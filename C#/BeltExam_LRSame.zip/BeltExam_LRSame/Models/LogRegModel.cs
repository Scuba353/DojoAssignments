using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeltExam.Models
{
    public class User: BaseEntity {
        
        [Key]
        public int userid { get; set; }
        public string FirstName { get; set; }
        public string Alias { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        // list of activities created by a user
        // [InverseProperty("Activity")]
        public List<Idea> ideaIcreated { get; set; }

        //list of activities user is attending
        //[InverseProperty("User")]
        public List<Like> mylikes { get; set; }

        public User(){
            mylikes= new List<Like>();
            ideaIcreated= new List<Idea>();
        }

    }
}