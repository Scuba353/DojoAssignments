using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeltExam.Models
{
    public class Like: BaseEntity {
        
        [Key]
        public int likeid { get; set; }
        public int userid { get; set; }
        
        [ForeignKey("userid")]
        public User User { get; set; }
        public int ideaid { get; set; }
        
        [ForeignKey("ideaid")]
        public Idea Ideas { get; set; }

        public int count { get; set;}
        

    }
}