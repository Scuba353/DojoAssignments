using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BeltExam.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace BeltExam.Controllers
{
    public class IdeasController : Controller
    {
        private BeltExamContext _context;

        public IdeasController(BeltExamContext context){
            _context= context;
        }

        [HttpGet]
        [Route("allideas")]
        public IActionResult AllIdeas()
        {
            ViewBag.username= HttpContext.Session.GetString("username");
            List<Idea> allideas= _context.Ideas.Include(x => x.Creator).Include(p => p.Likes).OrderByDescending(m => m.Likes.Count).ToList();
            ViewBag.alloftheideas= allideas;
            ViewBag.user= (int)HttpContext.Session.GetInt32("userid");


            return View("ideaspage");
        }

        [HttpPost]
        [Route("postidea")]
        public IActionResult PostIdea(string postidea)
        {
            Idea NewIdea = new Idea
            {
                idea = postidea,
                userid = (int)HttpContext.Session.GetInt32("userid"),
            };
            _context.Ideas.Add(NewIdea);
            _context.SaveChanges();

            return RedirectToAction("allideas");
        }

        [HttpGet]
        [Route("like/{id}")]
        public IActionResult LikeIdea(int id)
        {
            //need to check if relatinoship already exist in table and increment 1 if it does
            int curruser= (int)HttpContext.Session.GetInt32("userid");
            var alllikes= _context.Likes.Where(i => i.ideaid== id);
            int counter= 0;
                foreach(var t in alllikes){
                    if(t.userid == curruser){
                    counter= t.count +1;
                }
                else{
                    counter= 1;
                }
            }
            
            Like NewLike = new Like
            {
                userid = (int)HttpContext.Session.GetInt32("userid"),
                ideaid = id,
                count= counter
              
            };
            _context.Likes.Add(NewLike);
            _context.SaveChanges(); 

            return RedirectToAction("allideas");
        }

        [HttpGet]
        [Route("deleteevent/{id}")]
        public IActionResult DeleteEvent(int id)
        {
            List<Like> Creator = _context.Likes.Where(c =>c.ideaid ==id).ToList();
            foreach( var c in Creator)
            {
                _context.Likes.Remove(c);
            }

            Idea remove = _context.Ideas.SingleOrDefault(b => b.ideaid == id);
            _context.Ideas.Remove(remove);
            _context.SaveChanges();  

            return RedirectToAction("allideas");
        }

        [HttpGet]
        [Route("profile/{id}")]
        public IActionResult userprofile(int id)
        {
            int actid= id;
            int uid= (int)HttpContext.Session.GetInt32("userid");
            
            var person= _context.Ideas.Include(c => c.Creator).Include(p => p.Likes).SingleOrDefault(x => x.ideaid == id);
            //var person= _context.Ideas.Include(c => c.Creator).SingleOrDefault(x => x.ideaid == actid);
            ViewBag.person= person;
            
            //var game= _context.Ideas.Include(c => c.Creator).Include(p => p.Likes).SingleOrDefault(x => x.ideaid == actid);
            var game2= _context.Users.Include(c => c.ideaIcreated).SingleOrDefault(x => x.userid == uid);
            ViewBag.game2= game2;
            return View("userprofile");
        
        }

        [HttpGet]
        [Route("description/{id}")]
        public IActionResult description(int id)
        {
            int actid= id;
            var description= _context.Ideas.Include(c => c.Creator).Include(p => p.Likes).ThenInclude(u => u.User).SingleOrDefault(x => x.ideaid == actid);
            ViewBag.description= description;
            return View("description");
        
        }
    }
}







    
