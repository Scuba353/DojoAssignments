using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BeltExam.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace BeltExam.Controllers
{
    public class ActivityController : Controller
    {
        private BeltExamContext _context;

        public ActivityController(BeltExamContext context){
            _context= context;
        }

        [HttpGet]
        [Route("allactivities")]
        public IActionResult Allactivities()
        {
            List<Playit> allgames= _context.Activities.ToList();
            // List<Playit> allgames= _context.Activities.Include(x => x.Coordinator);
           
            ViewBag.allofthegames= allgames;

            // var allparticipants= _context.User_Activity_Join.Participants.Count();
            // TempData["sum"]= b;
            return View("activitypage");
        }

        [HttpPost]
        [Route("addactivity")]
        public IActionResult AddActivity()
        {
            return View("create");
        }

        [HttpPost]
        [Route("createactivity")]
        public IActionResult CreateActivity(Playit model, string span)
        {
            if(ModelState.IsValid)
                {
                    Playit NewActivity = new Playit
                    {
                        activity = model.activity,
                        date = model.date,
                        time = model.time,
                        duration = model.duration + span, 
                        description= model.description,
                        userid= (int)HttpContext.Session.GetInt32("userid")
                    };
                    _context.Activities.Add(NewActivity);
                    _context.SaveChanges();
                    HttpContext.Session.SetInt32("activityid", NewActivity.activityid);
                    return RedirectToAction("activitydescription");
                }
            return View("create", model);
        }

        [HttpGet]
        [Route("activitydescription")]
        public IActionResult activitydescription()
        {
            // int id= (int)HttpContext.Session.GetInt32("activityid");
            // Playit game= _context.Activities.SingleOrDefault(x => x.activityid == id);
            return View("description");
        
        }
    }
}







    
