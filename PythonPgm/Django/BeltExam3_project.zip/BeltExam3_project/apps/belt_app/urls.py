from django.conf.urls import url
from . import views

urlpatterns = [
	url(r'belt$', views.belt),
	url(r'addquote$', views.addquote),
	url(r'addtolist/(?P<id>\d+)', views.addfav),
	url(r'seestuff/(?P<id>\d+)', views.seestuff),
	url(r'removefromlist/(?P<id>\d+)', views.removestuff),
	
]