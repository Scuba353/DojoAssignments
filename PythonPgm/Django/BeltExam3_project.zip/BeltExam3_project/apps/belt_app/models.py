from __future__ import unicode_literals

from django.db import models
from ..logreg_app.models import User

# Create your models here.
class Quote(models.Model):
	creator= models.ForeignKey(User)
	quote_by= models.CharField(max_length=45)	
	quote= models.CharField(max_length=255)
	favorites= models.ManyToManyField(User, related_name="favs")
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)