from django.shortcuts import render, redirect
from django.contrib import messages
# Create your views here.
from .forms import QuoteForm
from .models import User, Quote


def belt(request):
	quoteform= QuoteForm()
	curr_user= User.objects.get(id=request.session['id'])
	context={
		"quoteform": quoteform,
		"allQuotes": Quote.objects.exclude(id=request.session['id']),
		"myfavs": Quote.objects.filter(favorites=curr_user)
	}
	return render(request, "belt/index.html", context)


def addquote(request):
	print "you are trying to add a quote"
	quotedata=QuoteForm(request.POST)
	print request.POST['user_id']
	user= User.objects.get(id=request.POST['user_id'])
	if quotedata.is_valid():
		quote_by = quotedata.cleaned_data['quote_by']
		quote = quotedata.cleaned_data['quote']

		print "you got here"
	 	Quote.objects.create(creator=user, 
					quote_by= quote_by, 
					quote=quote
					)
	 	return redirect('/belt')
	
def addfav(request, id):
	print "going to add a favorite"
	# To add data to many to many field. 
	curr_user= User.objects.get(id=request.session['id']) #set variable 
	quote_id= Quote.objects.get(id=id) #set varaible
	curr_user.favs.add(quote_id) #add user a to liked by field of book 1
	curr_user.save() #save
	print "added favorite"
	return redirect('/belt')

def seestuff(request, id):
	context={
	"user": User.objects.get(id=id),
	"count": Quote.objects.filter(creator__id=id).order_by("-count"),
	"quotes_user": Quote.objects.filter(creator__id=id)
	}
	return render(request, "belt/userquotes.html", context)

def removestuff(request, id):
	print "going to remove a favorite"
	curr_user= User.objects.get(id=request.session['id'])
	quote_id= Quote.objects.get(id=id)
	curr_user.favs.remove(quote_id) 
	curr_user.save()
	print "removed favorite"
	return redirect('/belt')
