from __future__ import unicode_literals

from django.db import models
from django.contrib import messages
from .forms import RegistrationForm, LoginForm
import bcrypt

# Create your models here.
class UserManager(models.Manager):
	def registrationvalid(self, postData):
		# errors=[]
		data=RegistrationForm(postData)
		if data.is_valid():
			name = data.cleaned_data['name']
			alias = data.cleaned_data['alias']
			email = data.cleaned_data['email']
			password =data.cleaned_data['password']
			confirm_password = data.cleaned_data['confirm_password']
			birthdate= data.cleaned_data['birthdate']

			if password != confirm_password:
				messages.error(request, "Passwords do not match.")
				print "pw dont match"
				return False
			
			user= User.objects.filter(email=email)
			if len(user) > 0: 
				messages.error(request, "Email is already being used, try Login.")
				print "same email"
				return False

			else: 
				print "you got here"
				new_user= User.objects.create(name=name, 
						alias= alias, 
						email=email,
						password= bcrypt.hashpw(password.encode(), bcrypt.gensalt()),
						birthdate=birthdate)
				return new_user

	def loginvalid(self, postData):
		# errors=[]
		data=LoginForm(postData)
		if data.is_valid():
			email = data.cleaned_data['email']
			password =data.cleaned_data['password']

			user = User.objects.filter(email=email)
			if len(user) < 1:
				messages.error(request, 'This Email does not exist. Try Regisering as a new user')
				return False

			else:
				if bcrypt.checkpw(password.encode(), user[0].password.encode()):
					return user

		
class User(models.Model):
	name= models.CharField(max_length=45)
	alias= models.CharField(max_length=45)	
	email= models.EmailField(max_length=255)
	password= models.CharField(max_length=255)
	birthdate= models.DateField()
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)
	objects= UserManager()