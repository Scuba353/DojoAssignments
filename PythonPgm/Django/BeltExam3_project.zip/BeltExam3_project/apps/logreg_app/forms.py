from django import forms

# from .models import User

class RegistrationForm(forms.Form):
	name = forms.CharField(max_length= 45, min_length=2)
	alias = forms.CharField(max_length= 45, min_length=2)
	email = forms.EmailField()
	password = forms.CharField(min_length=8)
	confirm_password = forms.CharField(min_length=8)
	birthdate= forms.DateField()

class LoginForm(forms.Form):
	email = forms.EmailField()
	password = forms.CharField(min_length=8)

class QuoteForm(forms.Form):
	quote_by = forms.CharField(max_length= 45, min_length=3)
	quote = forms.CharField(max_length= 45, min_length=10)