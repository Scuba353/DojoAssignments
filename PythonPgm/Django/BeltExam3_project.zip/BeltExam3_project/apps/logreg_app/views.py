from django.shortcuts import render, redirect
from django.contrib import messages
# Create your views here.
from .models import User

from .forms import RegistrationForm, LoginForm, QuoteForm

import re, bcrypt

def landing(request):
	regform = RegistrationForm()
	loginform= LoginForm()
	context = { 
		"regForm": regform,
		"logForm": loginform,
		"users": User.objects.all()
	}
	return render(request, "logreg/landing.html", context)

def registrationvalid(request):
	#this is grabbing the return either False or new_user from the models page
	print request
	user_valid = User.objects.registrationvalid(request.POST) 
	if user_valid == False:
		# request.session['errors'] = ""
		return redirect('/')
	else:
		request.session['name']=user_valid.name
		request.session['id']=user_valid.id
		return redirect('/belt')

def loginvalid(request):  
	user_exist = User.objects.loginvalid(request.POST) #this is grabbing the return either False or new_user from the models page
	if user_exist == False:
		# request.session['errors'] = ""
		return redirect('/')
	else:
		request.session['name']=user_exist[0].name
		request.session['id']=user_exist[0].id
		return redirect('/belt')

# def belt(request):
# 	quoteform= QuoteForm()
# 	context={
# 		"quoteform": quoteform,
# 		"allQuotes": Quote.objects.all()
# 	}
# 	return render(request, "belt/index.html", context)

def logout(request):
	request.session.flush()
	return redirect('/')








