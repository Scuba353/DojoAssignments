from django.conf.urls import url
from . import views

urlpatterns = [
	url(r'^$', views.landing),
	url(r'^register$', views.registrationvalid),
	url(r'^login$', views.loginvalid),
	# url(r'belt$', views.belt),
	url(r'logout$', views.logout),

]