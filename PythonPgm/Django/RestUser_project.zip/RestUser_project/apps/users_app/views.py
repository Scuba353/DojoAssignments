from django.shortcuts import render, redirect
from .models import User

def index(request):
	context = {
		"users": User.objects.all()
	}
	return render(request, 'users/index.html', context)

def show(request, id):
	# print id
	context = {
		"shows": User.objects.get(id=id)
	}
	# print context
	return render(request, "users/show.html", context)

def edit(request, id):
	return render(request, "users/edit.html", {'id':id})

def editUser(request, id, method=['POST']):
	update= User.objects.get(id=id)
	update.first_name= request.POST['f_name']
	update.last_name= request.POST['l_name']
	update.emial= request.POST['email']
	update.save()
	return redirect("/")

def new(request):
	return render(request, "users/new.html")

def create(request, method=['POST']):
	first= request.POST['f_name']
	last= request.POST['l_name']
	e=request.POST['email']
	User.objects.create(first_name=first, last_name= last, email=e).save()
	return redirect('/')

def delete(request, id):
	User.objects.get(id=id).delete()
	return redirect('/')