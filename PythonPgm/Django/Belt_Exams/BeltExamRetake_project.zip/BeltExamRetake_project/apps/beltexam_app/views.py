from django.shortcuts import render, redirect
from django.contrib import messages
# Create your views here.
from ..logreg_app.models import User, Poke

def success(request):
	# curr_user = User.objects.filter(name=request.session['name'])
	context={
		"people_to_poke": User.objects.all(),
		"poke_total": Poke.objects.get()

	}
	return render(request, "beltexam/index.html", context)

def poke(request, id):
	poker = User.objects.get(name=request.session['name'])
	poker.jabbs.add(id=id)
	print "poke added"
	return redirect('/success')


# def pokecount(request, id):
# 	context={
# 	"count": User.objects.count(jabs=(Poke.objects.get(id=id)))
# 	}
# 	return render(request, "beltexam/index.html", context)