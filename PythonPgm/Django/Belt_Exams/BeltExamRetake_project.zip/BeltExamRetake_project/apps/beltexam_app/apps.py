from __future__ import unicode_literals

from django.apps import AppConfig


class BeltexamAppConfig(AppConfig):
    name = 'beltexam_app'
