from django.shortcuts import render, redirect
from django.contrib import messages
# Create your views here.
from .models import Traveler, TravelPlans
from .forms import RegistrationForm, LoginForm, AddTripForm

import re, bcrypt

def index(request):
	regform = RegistrationForm()
	loginform= LoginForm()
	context = { 
		"regForm": regform,
		"logForm": loginform,
		"travelers": Traveler.objects.all()
	}
	return render(request, "loginreg/index.html", context)

def registrationvalid(request):
	if request.method == 'POST':
		data=RegistrationForm(request.POST)
		if data.is_valid():
			name = data.cleaned_data['name']
			username = data.cleaned_data['username']
			email = data.cleaned_data['email']
			password =data.cleaned_data['password']
			confirm_password = data.cleaned_data['confirm_password']

			if password != confirm_password:
				messages.error(request, "Passwords do not match.")
				print "pw dont match"
			
			try: 
				Traveler.objects.get(username=username)
				messages.error(request, "Username is already being used, try Login.")
				print "same email"
				return redirect('/')

			except: 
				print "you got here"
				request.session['username']=username 
				Traveler.objects.create(name=name, 
						username= username, 
						email=email,
						password= bcrypt.hashpw('password'.encode(), bcrypt.gensalt()))

				return redirect('/success')

def loginvalid(request):  
	if request.method == "POST":
		username = request.POST['username']
		password = request.POST['password']
		try:
			traveler = Traveler.objects.get(username=username)
		except:
			messages.error(request, 'This username does not exist. Try Regisering as a new user')
			return redirect('/')

		if bcrypt.checkpw('password'.encode(), traveler.password.encode()):
			request.session['name'] = traveler.name
			return redirect('/success')

def success(request):
	context= {
		#query where this user is going
		"traveler" : TravelPlans.objects.all()
	}
	return render(request, "loginreg/travel.html", context)

def logout(request):
	return redirect('/')

def addtravel(request):
	print "add travel"
	tripForm= AddTripForm()
	context = { 
		"tripForm": tripForm,
		}
	return render(request, "loginreg/addtravel.html", context)

def triprecord(request):
	print "createtravelrecord"
	request.session['username'] = username
	if request.method == 'POST':
		trip= AddTripForm(request.POST)
		if trip.is_valid():
			destination = trip.cleaned_data['destination']
			description =trip.cleaned_data['description']
			travel_start = trip.cleaned_data['travel_start']
			travel_end = trip.cleaned_data['travel_end']

			# if travel_start< datetime.now() or travel_start >= travel_end:
			# 	messages.error(request, "Select valid date range.")
			# 	print "bad dates"
			print "data valid"

		try:
			print "try to create record"
			print Traveler.objects.get(username=username) #set variable 
			# >>> b1= Book.objects.get(id=1) #set varaible
			# >>> a.liked_by.add(b1) #add user a to liked by field of book 1
			# >>> a.save() #save
			# traveler = Traveler.objects.get(username=username)
			TravelPlans.objects.create(destination=destination, description=description, travel_start=travel_start, travel_end=travel_end, peeps=traveler)
			print "record created"
			return redirect('/success')
		
		except:
			print "something failed"
			return redirect('/success')
		






