from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(), 
		# "leagues": League.objects.filter(sport="Baseball") #all baseball leagues
		# "leagues": League.objects.filter(name__contains="Womens") #all womens leagues
		# "leagues": League.objects.filter(sport__contains="hockey") #all leagues with any hockey sport
		# "leagues": League.objects.exclude(sport__contains="football") #all leagues where sport is not Football
		# "leagues": League.objects.filter(name__contains="Conference")# all leagues considered conferences
		# "leagues": League.objects.filter(name__contains="Atlantic") #all leagues in atlantic region		
		"teams": Team.objects.all(),
		# "teams": Team.objects.filter(location="Dallas") #all teams in Dallas
		# "teams": Team.objects.filter(team_name="Raptors") # all teams named Raptors
		# "teams": Team.objects.filter(location__contains="city") #all teams where location includes 'city'
		# "teams": Team.objects.filter(team_name__startswith="T") #all teams where team name starts with 'T'
		# "teams": Team.objects.order_by("location") #all teams ordered by location
		# "teams": Team.objects.order_by("-team_name") #all teams ordered in reverse alphabetical order
		"players": Player.objects.all(),
		# "players": Player.objects.filter(last_name="Cooper") #all players with last name Cooper
		# "players": Player.objects.filter(first_name="Joshua") #all players with first name Joshua
		# "players": Player.objects.filter(last_name="Cooper").exclude(first_name="Joshua") #all players with last name Cooper excluding  ones wiht first name Joshua
		# "players": Player.objects.filter(first_name="Alexander")|Player.objects.filter(first_name="Wyall") #all players with first name Alexander or Wyatt

	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")