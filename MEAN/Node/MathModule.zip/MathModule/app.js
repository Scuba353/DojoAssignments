var mathlib = require('./mathlib')();
mathlib.add(3, 7);
mathlib.multiply(3, 7);
mathlib.square(3);
mathlib.random(1, 7);
mathlib.random(3, 10);
mathlib.random(4, 70);
mathlib.random(2, 199);